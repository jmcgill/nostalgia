var a,b;
function foo(a,b){}
var x=function(){
return null;
return;
this.x;};

label:
for(var y=0;y<5;y++){
x[y]();
var z=new x(7,8);
var a=new x();
var b=new x.y(9);
break;
continue;}

switch(y){
case x:{
break;}
default:{
break;}}


debugger;

delete x[y];

while(false){}


do{}
 while(false);

if(typeof x){}


if(true){}
 else if(false){}
 else {}


try {}
 catch(e){}
 catch(f){}
 finally {}


for(x in y){}


for(var x in y){}


with(x){}


void x;
x instanceof y;