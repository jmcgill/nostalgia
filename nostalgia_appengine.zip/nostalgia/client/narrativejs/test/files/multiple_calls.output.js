function foo(){var njf1=njen(this,arguments);nj:while(1){switch(njf1.cp){case 0:njf1.pc(1,null,
  bar,[]);case 1:with(njf1)if((rv1=f.apply(c,a))==NJSUS){return fh;}njf1.pc(2,null,
  baz,[]);case 2:with(njf1)if((rv2=f.apply(c,a))==NJSUS){return fh;}
  doSomething();break nj;}}}
