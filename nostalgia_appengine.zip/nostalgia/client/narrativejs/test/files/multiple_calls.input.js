function foo() {
	bar->();
	baz->();
	doSomething();
}
